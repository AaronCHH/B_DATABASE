// capi.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#ifdef WIN32
int _tmain(int argc, _TCHAR* argv[])
#else

#end
{
	return 0;
}

